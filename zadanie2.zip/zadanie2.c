#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>


#define MAX_LINE_LEN 10024
#define MAX_PASSWORD_LEN 128
#define MAX_KEY_LEN 256
#define MAX_KEYS 100

typedef struct {
    char* username;
    char* password;
    char** keys;
    int num_keys;
    int num_users;
} User;

User* find_user(const char* username);
unsigned int hash_function(const char *str);
void remove_str(char* string_to_remove, User* currentUser);
char* user_to_string_except_key(User* usr, char* key_to_exclude, User* currentUser);


int main()
{
    FILE* file = fopen("hesla.csv", "r+");
    if (!file) {
        return EXIT_FAILURE;
    }

//    char* text = read_file("hesla.csv");
//    printf("%s", text);


    char name[MAX_KEY_LEN], password[MAX_PASSWORD_LEN], key[MAX_KEY_LEN];
    bool STATUS = false;

    printf("meno: ");
    scanf("%s", name);
    printf("heslo: ");
    scanf("%s", password);
    printf("overovaci kluc: ");
    scanf("%s", key);

//    find_user(name);

    char *testKey = calloc(strlen(key), sizeof(char));
    for (long unsigned int i = 0; i < strlen(key); ++i) {
        testKey[i] = key[i];
    } testKey[strlen(key)] = '\0';

    User* user = find_user(name);
    if (user)
    {
        char input_password_check_hash[strlen(user->password)+1];
        char pass_form_csv[strlen(user->password)+1];
        for (long unsigned int i = 0; i < strlen(user->password); ++i) {
            pass_form_csv[i] = user->password[i];
        } pass_form_csv[strlen(user->password)] = '\0';

        sprintf(input_password_check_hash, "%u", hash_function(password));

        if (strcmp(input_password_check_hash, pass_form_csv) == 0) {
//            printf("in2: %i- [%s]-[%s]\n", user->num_keys, user->keys[user->num_keys-1], testKey);

            for (int i = 0; i < user->num_keys; ++i) {

//                printf("in1: %s\n", user->keys[i]);
//                printf("in2: %s\n", testKey);

                if (strcmp(user->keys[i], testKey) == 0) {
                    STATUS = true;
                }
            }
            if (STATUS) {
                remove_str(key, user);
//                printf("num users: [%i]\n", user->num_users);
                printf("ok\n");
            } else {
                printf("chyba\n");
                for (int i = 0; i < user->num_keys; ++i) {
                    free(user->keys[i]);
                } free(user->keys);
                free(user);
                return EXIT_FAILURE;
            }
        } else {
            printf("chyba\n");
            for (int i = 0; i < user->num_keys; ++i) {
                free(user->keys[i]);
            } free(user->keys);
            free(user);
            return EXIT_FAILURE;
        }

        for (int i = 0; i < user->num_keys; ++i) {
            free(user->keys[i]);
        } free(user->keys);
        free(user);
    } else {
        printf("chyba\n");
    }

    return 0;
}



User* find_user(const char* username)
{
    FILE* file = fopen("hesla.csv", "r");
    if (!file) {
        perror("File opening failed");
        return NULL;
    }

    char buffer[MAX_LINE_LEN];
    User* user = calloc(1, sizeof(User));
    user->username = calloc(MAX_KEYS, sizeof(char));
    user->password = calloc(MAX_KEYS, sizeof(char));
    user->keys = calloc(MAX_KEYS, sizeof(char *));
    for (int i = 0; i < MAX_KEYS; ++i) {
        user->keys[i] = calloc(MAX_KEY_LEN, sizeof(char ));
    }

    user->num_users = 0;

    while (fgets(buffer, MAX_LINE_LEN, file))
    {
        user->num_users++;
        if (strstr(buffer, username) == NULL) continue;

        int i, ii = 0;

        for (i = 0; buffer[i] != ':'; i++) {
            user->username[i] = buffer[i];
        }
        user->username[i] = '\0';
        ++i;

        for (int k = 0, j = i; buffer[j] != ':'; ++j, ++k, ++i, ++ii) {
            user->password[k] = buffer[j];
        }

        user->password[ii] = '\0';
        ++i;

        char *buf_key = calloc(MAX_KEY_LEN, sizeof(char));

        for (int j = i, iter = 0, numKey = 0; buffer[j-1] != '\n' ; ++j, ++i, ++iter)
        {
            buf_key[iter] = buffer[j];

            if (buffer[j] == ',' || buffer[j] == '\n')
            {
                buf_key[iter] = '\0';

                for (int k = 0; k < iter; ++k) user->keys[numKey][k] = buf_key[k];

                user->keys[numKey][iter] = '\0';
                numKey++;
                user->num_keys = numKey;
                iter = -1;
                memset(buf_key, 0, MAX_KEY_LEN * sizeof(char));

                continue;
            }
        }

        free(buf_key);

        while (fgets(buffer, MAX_LINE_LEN, file)) {
            user->num_users++;
        }

        break;
    }
    fclose(file);

    return user;
}



unsigned int hash_function(const char *str)
{
    unsigned int hash = 5381;int ch;
    while ((ch = *str++)) {
        hash = ((hash << 5) + hash) + (unsigned int)ch;
    } return hash;
}


char* user_to_string_except_key(User* usr, char* key_to_exclude, User* currentUser) {
    char* output = calloc(200, sizeof(char));

    sprintf(output, "%s:%s:", usr->username, usr->password);
    for (int i = 0; i < usr->num_keys; i++) {
        if (strcmp(usr->username, currentUser->username) == 0) {
            if (strcmp(usr->keys[i], key_to_exclude) != 0) { // исключаем ключ, если он не совпадает с key_to_exclude
                strcat(output, usr->keys[i]);
                if (i < usr->num_keys - 1) {
                    strcat(output, ",");
                }
            }
        } else {
            strcat(output, usr->keys[i]);
            if (i < usr->num_keys - 1) {
                strcat(output, ",");
            }
        }

    }
    return output;
}


void remove_str(char* string_to_remove, User* currentUser)
{
    User* user1 = find_user("user1");
    User* user2 = find_user("user2");
    User* user3 = find_user("user3");
    User* user4 = find_user("user4");
    User* user5 = find_user("user5");

    FILE* fp = fopen("hesla.csv", "w");
    if (fp == NULL) exit(EXIT_FAILURE);

    char *output1 = user_to_string_except_key(user1, string_to_remove, currentUser);
    for (long unsigned int i = 0; i < strlen(output1); ++i)if (output1[i] == ',' && output1[i+1] == '\0') output1[i] = '\0';
    fprintf(fp, "%s\n", output1);

    char *output2 = user_to_string_except_key(user2, string_to_remove, currentUser);
    for (long unsigned int i = 0; i < strlen(output2); ++i) if (output2[i] == ',' && output2[i+1] == '\0') output2[i] = '\0';
    fprintf(fp, "%s\n", output2);

    char *output3 = user_to_string_except_key(user3, string_to_remove, currentUser);
    for (long unsigned int i = 0; i < strlen(output3); ++i) if (output3[i] == ',' && output3[i+1] == '\0') output3[i] = '\0';
    fprintf(fp, "%s\n", output3);

    char *output4 = user_to_string_except_key(user4, string_to_remove, currentUser);
    for (long unsigned int i = 0; i < strlen(output4); ++i) if (output4[i] == ',' && output4[i+1] == '\0') output4[i] = '\0';
    fprintf(fp, "%s\n", output4);

    char *output5 = user_to_string_except_key(user5, string_to_remove, currentUser);
    for (long unsigned int i = 0; i < strlen(output5); ++i) if (output5[i] == ',' && output5[i+1] == '\0') output5[i] = '\0';
    fprintf(fp, "%s\n", output5);

    free(output1);
    free(output2);
    free(output3);
    free(output4);
    free(output5);

    free(user1);
    free(user2);
    free(user3);
    free(user4);
    free(user5);

    fclose(fp);
}








void free_user(User* user) {
    free(user->username);
    free(user->password);
    for (int i = 0; i < user->num_keys; i++) {
        free(user->keys[i]);
    }
    free(user->keys);
    free(user);
}
